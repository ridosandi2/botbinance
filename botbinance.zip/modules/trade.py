from binance.client import Client
from modules.config_loader import config
from modules.logger_setup import logger
from modules.telegram_bot import send_telegram_message

client = Client(config["api_key"], config["api_secret"])

def place_order(symbol, side, qty, tp, sl):
    try:
        balances = client.futures_account_balance()
        usdt_balance = next((b for b in balances if b["asset"] == "USDT"), None)
        if usdt_balance and float(usdt_balance["balance"]) < 10:
            error_msg = f"❌ Saldo USDT terlalu rendah: {usdt_balance['balance']}"
            logger.error(error_msg)
            send_telegram_message(error_msg)
            return

        client.futures_change_leverage(symbol=symbol, leverage=config["leverage"])

        ticker = client.futures_symbol_ticker(symbol=symbol)
        entry_price = float(ticker["price"])

        min_order_value = 5
        min_qty = min_order_value / entry_price
        adjusted_qty = max(qty, min_qty)

        order = client.futures_create_order(
            symbol=symbol,
            side=side,
            type="MARKET",
            quantity=adjusted_qty
        )

        entry_price = float(order['avgFillPrice']) if 'avgFillPrice' in order else None

        if entry_price:
            tp_price = round(entry_price * (1 + config["take_profit_percent"] / 100 if side == "BUY" else 1 - config["take_profit_percent"] / 100), 2)
            sl_price = round(entry_price * (1 - config["stop_loss_percent"] / 100 if side == "BUY" else 1 + config["stop_loss_percent"] / 100), 2)

            client.futures_create_order(
                symbol=symbol,
                side="SELL" if side == "BUY" else "BUY",
                type="LIMIT",
                quantity=adjusted_qty,
                price=tp_price,
                reduceOnly=True,
                timeInForce="GTC"
            )

            client.futures_create_order(
                symbol=symbol,
                side="SELL" if side == "BUY" else "BUY",
                type="STOP_MARKET",
                quantity=adjusted_qty,
                stopPrice=sl_price,
                reduceOnly=True
            )

            success_msg = f"🟢 Order {side} {symbol} ditempatkan: {entry_price}, TP: {tp_price}, SL: {sl_price}, Qty: {adjusted_qty}"
            logger.info(success_msg)
            send_telegram_message(success_msg)

    except Exception as e:
        error_msg = f"❌ Gagal menempatkan order {side} {symbol}: {e}"
        logger.error(error_msg)
        send_telegram_message(error_msg)
