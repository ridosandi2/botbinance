import json

class Config:
    def __init__(self, config_path='config.json'):
        with open(config_path, 'r') as f:
            self._raw = json.load(f)
        self.binance = self._raw.get("binance", {})
        self.telegram = self._raw.get("telegram", {})
        self.database = self._raw.get("database", {})
        self.trading = self._raw.get("trading", {})
        self.blacklist = self._raw.get("blacklist", {})
