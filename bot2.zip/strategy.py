from analysis import compute_MACD, compute_RSI, compute_BollingerBands

class Strategy:
    def __init__(self):
        self.prices = {}

    def on_price_update(self, symbol, price, closed=False):
        hist = self.prices.setdefault(symbol, [])
        hist.append(price)
        if len(hist) > 200:
            hist.pop(0)
