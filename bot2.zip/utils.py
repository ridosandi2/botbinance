import time, random

def apply_flexible_delay(base_delay=1.0, random_factor=0.5):
    time.sleep(base_delay + random.uniform(0, random_factor))
