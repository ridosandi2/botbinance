from binance import ThreadedWebsocketManager

class WebSocketManager:
    def __init__(self, client):
        self.client = client
        self.twm = ThreadedWebsocketManager(api_key=client.API_KEY, api_secret=client.API_SECRET)
    
    def start(self):
        self.twm.start()
