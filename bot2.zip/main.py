import logging
import time
from config_loader import Config
from db import TradeDatabase
from telegram_bot import TelegramBot
from binance_client import BinanceClient
from websocket_manager import WebSocketManager
from trader import Trader
from strategy import Strategy

# Setup Logging
logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s - %(message)s')

# Load Configuration
config = Config('config.json')

# Initialize Components
db = TradeDatabase(config.database['file'])
telegram_bot = TelegramBot(config.telegram['bot_token'], config.telegram['chat_id'])
binance_client = BinanceClient(config.binance['api_key'], config.binance['api_secret'], config.binance.get('testnet', False))
trader = Trader(binance_client.client, db, telegram_bot)
strategy = Strategy()

# Start WebSockets
ws_manager = WebSocketManager(binance_client.client)
ws_manager.start()
ws_manager.start_user_stream(trader.on_order_update)
ws_manager.start_market_stream(trader.symbols, interval="1m", market_callback=strategy.on_price_update)

# Main Trading Loop
trading_paused = False
try:
    while True:
        # Check Telegram commands
        cmds = telegram_bot.get_commands()
        for cmd in cmds:
            if cmd.lower() == "/pause":
                trading_paused = True
                telegram_bot.send_message("Trading paused by user.")
            elif cmd.lower() == "/resume":
                trading_paused = False
                telegram_bot.send_message("Trading resumed.")

        if trading_paused:
            time.sleep(1)
            continue

        time.sleep(config.loop_interval)
except KeyboardInterrupt:
    logging.info("Bot shutting down...")
    ws_manager.stop()
