from binance.client import Client
from strategy import Strategy

client = Client()

def backtest(symbol, start_str="1 month ago UTC"):
    klines = client.get_historical_klines(symbol, Client.KLINE_INTERVAL_1MINUTE, start_str)
    prices = [float(k[4]) for k in klines]
    strategy = Strategy()
    for i, price in enumerate(prices):
        closed = (i == len(prices)-1) or True
        strategy.on_price_update(symbol, price, closed)
