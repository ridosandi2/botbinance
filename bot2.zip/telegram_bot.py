import requests

class TelegramBot:
    def __init__(self, token, chat_id):
        self.token = token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{token}"

    def send_message(self, text):
        url = f"{self.api_url}/sendMessage"
        payload = {"chat_id": self.chat_id, "text": text}
        requests.post(url, data=payload)
