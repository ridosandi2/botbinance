import logging

class Trader:
    def __init__(self, binance_client, db, telegram_bot):
        self.client = binance_client
        self.db = db
        self.telegram = telegram_bot
        self.open_positions = {}
