import pandas as pd

def compute_MACD(close_prices, fast=12, slow=26, signal=9):
    prices = pd.Series(close_prices)
    exp1 = prices.ewm(span=fast, adjust=False).mean()
    exp2 = prices.ewm(span=slow, adjust=False).mean()
    macd_line = exp1 - exp2
    signal_line = macd_line.ewm(span=signal, adjust=False).mean()
    histogram = macd_line - signal_line
    return macd_line.iloc[-1], signal_line.iloc[-1], histogram.iloc[-1]

def compute_RSI(close_prices, period=14):
    prices = pd.Series(close_prices)
    delta = prices.diff()
    up = delta.clip(lower=0)
    down = -1 * delta.clip(upper=0)
    avg_gain = up.rolling(window=period).mean()
    avg_loss = down.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi.iloc[-1]

def compute_BollingerBands(close_prices, period=20, std_dev=2):
    prices = pd.Series(close_prices)
    sma = prices.rolling(window=period).mean()
    std = prices.rolling(window=period).std()
    middle = sma.iloc[-1]
    upper = middle + std_dev * std.iloc[-1]
    lower = middle - std_dev * std.iloc[-1]
    return middle, upper, lower
