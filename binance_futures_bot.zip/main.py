import time
from modules.config_loader import config
from modules.logger_setup import logger
from modules.trade import place_order
from modules.indicators import compute_rsi, compute_macd, compute_bollinger_bands
from modules.websocket_handler import start_websocket, price_history
from modules.telegram_bot import handle_telegram_commands

# Daftar simbol yang dipantau
symbols = config.get("symbols", ["BTCUSDT", "ETHUSDT", "BNBUSDT"])

# Jalankan WebSocket sebelum loop utama
start_websocket()

while True:
    handle_telegram_commands()
    time.sleep(1)  # Gunakan delay pendek agar bot merespons lebih cepat
