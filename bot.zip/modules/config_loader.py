import json

def load_config():
    """Memuat konfigurasi dari file config.json"""
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except Exception as e:
        print(f"⚠️ Gagal memuat konfigurasi: {e}")
        return {}

config = load_config()
