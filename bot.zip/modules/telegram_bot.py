import requests
from modules.config_loader import config
from modules.logger_setup import logger

TELEGRAM_URL = f"https://api.telegram.org/bot{config['telegram_bot_token']}/sendMessage"

def send_telegram_message(text):
    """Kirim pesan ke Telegram dengan error handling"""
    try:
        response = requests.post(TELEGRAM_URL, data={"chat_id": config["telegram_chat_id"], "text": text})
        result = response.json()
        if result.get("ok"):
            logger.info(f"📨 Telegram sent: {text}")
        else:
            logger.error(f"⚠️ Gagal mengirim Telegram: {result}")
    except Exception as e:
        logger.error(f"⚠️ Gagal mengirim Telegram: {e}")

def handle_telegram_commands():
    """Proses pesan dari Telegram"""
    send_telegram_message("✅ Bot Aktif! Memantau market...")
